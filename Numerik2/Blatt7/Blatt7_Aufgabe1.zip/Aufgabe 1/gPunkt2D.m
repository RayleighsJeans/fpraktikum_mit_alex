function [g,w] = gPunkt2D
    % Schwerpunktformel für Referenzdreieck
    g(1,1) = 1/3;
    g(1,2) = 1/3;
    w(1) = 1/2;
end