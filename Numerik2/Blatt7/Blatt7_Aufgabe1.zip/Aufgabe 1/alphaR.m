function alpha = alphaR(x,y)
   if (y>0)
       alpha = 2;
   else
       alpha = 0;
   end
end