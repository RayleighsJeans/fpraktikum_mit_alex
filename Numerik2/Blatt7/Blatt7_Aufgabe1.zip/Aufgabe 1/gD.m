function dirichlet = gD(x,y)
   dirichlet = 1; 
end