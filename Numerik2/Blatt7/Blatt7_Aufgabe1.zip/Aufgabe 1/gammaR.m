function gamma = gammaR(x,y)
  gamma = 1;
end