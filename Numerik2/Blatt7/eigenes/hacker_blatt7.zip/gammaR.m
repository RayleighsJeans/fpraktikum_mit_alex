function gamma = gammaR(x,y)
  if (y>0)
       gamma = 1;
   else
       gamma = 0;
   end
end