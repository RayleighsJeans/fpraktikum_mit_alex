function dirichlet = gD(x,y)
   if (x<=1.)
        dirichlet = 0;
   elseif (x>=3.)
        dirichlet = 3; 
   else
        return
   end
end