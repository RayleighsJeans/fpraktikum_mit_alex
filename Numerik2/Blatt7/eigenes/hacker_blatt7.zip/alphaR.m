function alpha = alphaR(x,y)
   if (y>0)
       alpha = 3;
   else
       alpha = 0;
   end
end