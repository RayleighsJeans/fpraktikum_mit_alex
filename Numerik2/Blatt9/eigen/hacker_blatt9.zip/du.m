function d = du(x,y)
   d = [0;0];
end