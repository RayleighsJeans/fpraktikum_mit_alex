function alpha = alphaR(x,y)
   alpha = 0.55;
end