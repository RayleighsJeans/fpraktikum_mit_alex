function c = cu(x,y)
    c = 0;
end