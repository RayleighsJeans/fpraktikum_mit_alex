function gamma = gammaR(x,y)
   gamma = 0.55*160;
end