function a = au(x,y)
   a = 0.98e-3;
end