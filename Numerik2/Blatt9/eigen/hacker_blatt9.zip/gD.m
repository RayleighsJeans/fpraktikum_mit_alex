function dirichlet = gD(x,y)
    dirichlet = 0;
end