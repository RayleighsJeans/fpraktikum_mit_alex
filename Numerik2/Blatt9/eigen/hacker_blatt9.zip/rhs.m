function f = rhs(x,y)
  f = 0; 
end